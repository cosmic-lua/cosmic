# Step 0 performance evidence

Warm-cache, same-host paired observations for the explanatory-artifact series.
No competing builds, tests, fuzzers or benchmarks ran during these windows.
These measurements screen for measurable regressions; they do not prove zero
regression. Fresh processes are not cold filesystem-cache measurements.

## Sources and controller

- Parent: released `8e4a899230c24ddd90a52d00be2abd3375dfd546` artifact, independently
  verified against the GitHub release asset digest.
- Initial run-02 candidate: the implementation working tree based on that parent,
  before the final metadata/filter/documentation refinements. Its exact executable
  digest is retained below and in metadata. The script itself was not fingerprinted
  by that earlier harness revision; do not pretend this run names the final commit.
- Final run-03 candidate: local commit
  `7fdf80ddba64131d1b53d08f1cb1d0b60241bea8`, based on
  `3f239b115f532b4ecd6d17f30e020434187c86be`. The intervening main change only
  adjusted entrypoint documentation/type comments. Root published the identical
  source tree as `c7682e470ac28492340ab06f3304ce9daf02b74b` in PR #2563.
- Fixed controller for both sides in both runs: pinned bootstrap release
  `b951ab95c1250176bea35a2862c4221ad7210893`, artifact SHA-256
  `24c8dacbbd42eef3dd2a923fa4f9761e5d1aab293666e564a3ddce53a3eac7b5`.
- Controller SQLite 3.53.4. Runtime target/configuration, core/SQLite/compiler
  identities, host/kernel/CPU, cache modes, raw commands and artifact paths are
  retained with each run. Both sides used the same optimized host target.

| Artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| Parent | 14995504 | 6b0484154389a4b603b9c1021f5be3eca9055c6b753f56c81a6afbbd3042272d |
| run-02 candidate | 15024176 | 4b4d597ed36711e03a92be17741e5c7bc8bcdee8fbfc40e4ef9bab83af21ecf8 |
| Final candidate | 15024176 | b88a52e2388ca4a7a9a8a07fbadf24eecf69250c8caa97916751e3e5ab496165 |

Final size increased by 28,672 bytes; size is advisory.

## Commands and observations

From the implementation checkout:

```sh
COSMIC_PERF_BASELINE_COMMIT=8e4a899 COSMIC_PERF_CANDIDATE_COMMIT=8e4a899-working \
bin/perf /workspace/scratch/f8ba688da080/artifact-measurements/baseline-8e4a899 \
  /workspace/scratch/f8ba688da080/cosmic-perf/o/bin/cosmic \
  /workspace/scratch/f8ba688da080/artifact-measurements/run-02

COSMIC_PERF_BASELINE_COMMIT=8e4a899230c24ddd90a52d00be2abd3375dfd546 \
COSMIC_PERF_CANDIDATE_COMMIT=7fdf80ddba64131d1b53d08f1cb1d0b60241bea8 \
bin/perf /workspace/scratch/f8ba688da080/artifact-measurements/baseline-8e4a899 \
  /workspace/scratch/f8ba688da080/cosmic-perf/o/bin/cosmic \
  /workspace/scratch/f8ba688da080/artifact-measurements/run-03-packaging \
  100 embed_portable
```

run-02 used 30 A/A pairs and 30 A/B pairs per workload, with three checked
warmups per phase and a predeclared complete repeat when inconclusive. It
retains 2,400 measured observations across 15 workloads; 14 passed and portable
packaging remained inconclusive. All workload output/counter checks passed.
Its portable-packaging paired median delta was +0.024 ms with a 95% sign interval
[-2.939, +1.218] ms. The empirical p95 increased by 5.187 ms, exceeding the
2.045 ms A/A resolution: this uncertainty was not discarded.

The coordinator then predeclared a targeted 100-pair A/A and A/B follow-up for
portable packaging on the final source. run-03 retains 400 measured observations
and passed without requiring its optional repeat. Medians were 104.619 ->
103.092 ms; paired median delta -0.691 ms, 95% sign interval [-2.116, +0.387] ms;
p95 126.575 -> 119.218 ms. A/A practical resolution was 1.736 ms. This resolves
the earlier packaging question without claiming exact-zero slowdown.

Final controller timer-pair median was 61 ns. Child supervision plus
`/usr/bin/true` had median 1.092 ms; it is reported, never subtracted.

## Validation and limits

- Pinned `bin/zig build boot` passed in a clean current-main worktree.
- `cosmic fix` on changed source and documentation passed.
- Seven focused performance-statistics tests passed.
- `cosmic fix --check .` passed: 641 files, zero tree findings.
- `cosmic todos` on changed paths reported zero TODOs.
- Prescribed `timeout 30 cosmic test` cancelled while preparing the fresh
  3,235-test run, before any new full-suite results were committed. Only the
  seven focused results existed afterward, zero failures. This is a timeout,
  not a successful full-suite run and not an assertion failure. Remote required
  CI remains the full correctness/sandbox gate.
- This host refuses user namespaces. Fixture tests deliberately ran unsandboxed
  with shared compile/verdict caches disabled; no sandbox claim is made.
- Cold I/O, peak RSS and realistic larger-project scaling remain unmeasured.
- An earlier original-baseline worktree met ENOSPC and corrupt working-DB
  symptoms. Its diagnostics were preserved separately; its measurements are
  excluded. A clean current worktree and the released parent supplied these
  valid runs.

## Archive contents

`raw.json` excludes warmups and combines measured observations. The per-phase
files under each run's `a/o/perf/` include checked warmups in paired order (A then B in the file);
`pair` records the alternating execution order: odd pairs ran A first, even
pairs B first. `label` identifies the side.
Per-sample command lines, elapsed times, stdout/stderr, and before/after build
counters are retained. Initial, repeat (where that harness revision wrote one),
and pooled summaries are included; raw phase records permit recomputation.
The run-02 harness did not yet persist a separate repeat-summary file, so use
its repeat phase records rather than inventing one. Setup, runtime/compiler
facts, query plans and final Teal fixture contents are included (leaf-edit samples used the
recorded pair number plus 1000 as their new leaf value).
Executables, working databases and regenerable closure stores are omitted.

Raw SHA-256:
- run-02/raw.json: 805a6c0c2346b3ee07cb56c68365e0f18db5f6b0c907d9db52166bec1afa11cc
- run-03-packaging/raw.json: 853e7fd421692f02015260e8e677a3d4570315c6da7d094abb846fae0c1c318d
